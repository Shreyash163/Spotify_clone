const PlayList = [
  { id: 1, name: "Top hits of 2022" },
  { id: 2, name: "Dance" },
  { id: 3, name: "Relaxing" },
  { id: 4, name: "Instrumental" },
  { id: 5, name: "Hip-hop" },
  { id: 6, name: "Indian" }
];
export default PlayList;
